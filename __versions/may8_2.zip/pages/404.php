<?php

	require "../initialize.php";
	$page_link = "404";
	$page_title = "Page not found";
	$page_description = "This is the page that displays when you use a misspelled or broken link.";
	$page_keywords = "404 error page";

	loadHeader("main");
	loadUI("main");
	loadFooter("main");
