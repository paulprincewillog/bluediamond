<?php
			
	// Define DB parameters
	define("DB_HOST", "localhost");
	define("DB_USER", "root");
	define("DB_PASSWORD", "");
	define("DB_NAME", "school");
	define("USER", "phone_number");
	define("USER_TABLE", "contacts");
	define("GENERAL_TITLE", "Blue Diamond Schools Effurun");
	
	// Define URL
	define("ROOT_PATH", "bluediamond/");
	define("ROOT_URL", "http://localhost/bluediamond/");

	define("BACKEND", "apps/backend/");	
	define("FRONTEND", "apps/frontend/");
	define("_UI", "ui/");
	define("_FRONTEND_LIB", FRONTEND."_lib/");
	define("_BACKEND_LIB", BACKEND."_lib/");


	// Define prefix
	define("PREFIX", "bluedds");

	// Define version
	define("VERSION", "10");

	// https://github.com/matthiasmullie/minify to minify files
	// <script async src="my.js">