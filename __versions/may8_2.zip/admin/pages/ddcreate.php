<?php

	include "../../initialize.php";
	loadHeader('noheader');
	loadUI('main');
	loadFooter('main');
?>