<?php

    if (!isset($_SESSION[PREFIX."_admin"])) {
        return;
    }