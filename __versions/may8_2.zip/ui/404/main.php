<h1>
   404 error
</h1>
<p>
    We could not find the page you are looking for. Maybe the link you used is misspelled or does not exist anymore.
</p>

</p>
<p id="back"> Are you here as a parent wanting to know more about our school? </p>
<a href="<?php echo ROOT_URL; ?>"> <button> Go to homepage <i class="pe-7s-angle-right arrow_right"></i>  </button> </a> 