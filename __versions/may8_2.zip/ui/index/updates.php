<section id="updates" class="modal"> 

	<div>

		<small class="dd_shortline">Last updated <span dd_display="date"></span> </small>
		<p dd_display="content"> 
			<span class="dd_longline"></span>
			<span class="dd_shortline"></span>
		</p> 

		<a dd_attr="id" href="[link]" target="_blank" class="for_more"> Click here <i class="icon pe-7s-angle-right"></i> </a>
		<a onclick="dd('#updates').fadeOut(500)" class="close_button"> <i class="icon pe-7s-close"></i> <span> Close </span> </a>
	</div>

</section>