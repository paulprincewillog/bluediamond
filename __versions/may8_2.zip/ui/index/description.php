
<!-- This section covers #top_description and #about. 
    It starts here and ends in about.php
-->
<section id="home" class="current_view">

    <div id="top_description">

        <div>

            <h3> Welcome to <span itemprop="name"> Blue Diamond schools Effurun </span> </h3>
            <h1 title="Welcome">
                Affordable high standard education for every parent.
            </h1>

            <a href="tel: 08028676295"> <button class="dd_button" title="call us now"> Call us now <i class="pe-7s-call arrow_right"></i> </button> </a>
            
            <button id="latest_update" onclick="latest_update()"> Latest updates 
                <span class="blinking_circle"></span>
            </button>

            <!-- <span> Features <span class="arrow"> <i class="pe-7s-angle-down"></i> </span> </span> -->

        </div>

    </div>
