
    </main>

    <footer>
        
        <!-- <a> Contact us </a> -->
        <a href="refer"> Refer someone </a>
        <a href="contact"> Contact us </a>
        <p> <span> &copy; </span> Blue Diamond Schools <?php echo date('Y'); ?> </p>
   
    </footer>

</body>
</html>