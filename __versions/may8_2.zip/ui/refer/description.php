
<!-- This section covers #top_description and #about. 
    It starts here and ends in about.php
-->
<section id="top_description">

    <h1> Refer someone to our school in Effurun</h1>
    <p name="caption">
        Blue Diamond schools is on a mission to make high standard education affordable and stand out as one of the best schools in Effurun. 
        
        <br> <br> If you know anyone who lives along PTI Road, Osubi, Okuokoko, Alegbo, UTI Road, Ebrumede and other neighbouring environment, refer them to us if they are looking for an affordable high standard school for their child. And we will support you with <b> ₦3000 </b> if they register.
    </p>

</section>
