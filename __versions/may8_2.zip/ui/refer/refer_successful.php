<section id="refer_successful" class="forms">
    <p> We have taken note of the phone number you submitted. Thank you so much. Do you know any other parent you would like to refer? </p>
    <button onclick="refer_again()"> Yes </button>
    <button onclick="continue_refer()"> No </button>
</section>