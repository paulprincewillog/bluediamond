
    </main>

    <footer>
        <!-- <a> Contact us </a> -->
        <a href="refer"> Refer someone </a>
        <a href="https://web.facebook.com/Blue-Diamond-Schools-100163038732037/"> <img src="_assets/icons/facebook-grey.svg" alt="Facebook logo"> Facebook </a>
        <a href="https://wa.me/2348028676295?text=I am messaging from Blue Diamond school and I want to ... "> <img src="_assets/icons/whatsapp-grey.svg" alt="WhatsApp Logo"> WhatsApp </a>
        <p> <span> &copy; </span> Blue Diamond Schools <?php echo date('Y'); ?> </p>
    </footer>

</body>
</html>