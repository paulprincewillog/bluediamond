function dd_initialize() {
    
}