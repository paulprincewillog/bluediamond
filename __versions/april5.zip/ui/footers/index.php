
    </main>

    <footer>
        <a> Contact us </a>
        <a> <img src="_assets/icons/facebook-grey.svg"> Facebook </a>
        <a> <img src="_assets/icons/whatsapp-grey.svg"> WhatsApp </a>
        <p> <span> &copy; </span> Blue Diamond Schools <?php echo date('Y'); ?> </p>
    </footer>

</body>
</html>