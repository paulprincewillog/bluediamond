<?php

	require "../../initialize.php";
	$page_link = "index";
	$page_title = "index";
	$page_description = "index";
	$page_keywords = "index";

	loadHeader("noheader");
	loadUI("main");
	loadFooter("main");
