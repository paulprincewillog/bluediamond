<h1>
    Welcome to your new page. Open <b> <?php echo UI.$page_link."/main.php";?> </b> to edit
</h1>