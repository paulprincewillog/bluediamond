<!DOCTYPE html>
<html>
	<head>
		<title> <?php echo $page_title?> | Amara </title>
		<link rel='stylesheet' href='ui/<?php echo $page_link ?>/_styles.dd.css'>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
	</head>

	<body>

		<!-- This is a basic component of dodo ajax loading, you can put it anywhere, but don't delete it -->
		<dodo></dodo>
		<loader></loader>
		<header> 
		</header>

		<main id='page_<?php echo $page_link?>'>


