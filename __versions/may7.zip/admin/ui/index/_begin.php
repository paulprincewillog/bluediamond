<div id="admin_section">
        
    <div class="navigation">
        <div class="prev_view">
            <button onclick="change_slide('previous')"> <i class="pe-7s-angle-left"></i> </button>
            <span class="next_line"> Back </span>
        </div>
    </div>