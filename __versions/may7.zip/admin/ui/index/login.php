<section id="admin_login" backTo="home" class="active_admin_screen">
    <form action="app/admin/login">

        <section>
            <i class="pe-7s-lock"></i>
            <p> Welcome back Admin. Type in your password below to continue </p>
        </section> 

        <input type="password" name="password" placeholder="Admin password">
        <button type="submit"> LOGIN </button>
        
    </form>
</section>