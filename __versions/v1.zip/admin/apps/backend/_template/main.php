<?php
	include "../../../initialize.php";
    $x['dd_success'] = true;
    $x['dd_feedback'] = "This page is now active";

    echo json_encode($x);