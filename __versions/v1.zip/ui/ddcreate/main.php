<form id="createForm" action="app/ddcreate/new" dd_submit="yes">

	<input type="text" name="page_name" placeholder="Page name" required>
	<input type="text" name="page_title" placeholder="Page title">
	<textarea type="text" name="page_description" placeholder="Meta description"></textarea>
	<input type="text" name="page_keywords" placeholder="Meta keywords">

	<p align="center"> <input type="submit" id="createPage" value="Go →"> </p>

</form>
