
<!-- This section covers #top_description and #about. 
    It starts here and ends in about.php
-->
<section id="top_description">

    <h1> Refer someone </h1>
    <p name="caption">
        Blue Diamond schools is on a mission to make high standard education affordable. Refer a parent to join this mission and we will support you with <b> ₦3000 </b> if they register.
    </p>

    <p name="prompt"> Click on an option below <i class="pe-7s-angle-down arrow"></i> </p>
    <div name="actions">
        <a onclick="submit_details('refer')"> <span> Refer someone using phone number </span> <i class="pe-7s-angle-right"></i> </a>
        <a onclick="submit_details('link')"> <span> Share our website link with everyone </span>  <i class="pe-7s-angle-right"></i>  </a>
    </div>

</section>