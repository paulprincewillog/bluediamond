<section id="contact">

    
    <h3 id="contact_title">
        <span class="title_line"> Contact us  </span>
        <button class="arrow"> <i class="pe-7s-angle-down"></i> </button>
    </h3>

    
    <div id="contact_details">
        
        <section id="contact_address"> 

            <div id="address"> 
                <p> 166 PTI Road, beside RainOil filling station, Effurun, Delta State. </p>
                <a href="https://goo.gl/maps/gCGzJaTsvk7Xo5Vb8"> View full map <i class="icon pe-7s-angle-right"> </i></a>
            </div>
            <div id="map">
                <iframe src="" width="100%" height="100%" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0" loading="lazy" id="iframe_map"></iframe>
            </div>

        </section>
        
        <section id="other_contacts">
         
            <div class="phone_number">
                <p> 0802 867 6295 </p> 
                <a href="tel: 08028676295">
                    <i class="icon pe-7s-call"></i>
                </a> 
            </div>

            <div class="phone_number">
                <p> 0703 108 4963 </p> 
                <a href="tel: 07031084963">
                    <i class="icon pe-7s-call"></i>
                </a> 
            </div>

            <div id="email_header"> 
                <i class="icon pe-7s-mail"></i> 
                <p> Reach us through <span> contact@bluediamondschools.com</span>  or send a mail using the form above. </p>
            </div>
            
        </section>

    </div>


</section>
