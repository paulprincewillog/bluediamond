<section class="navigation">

    <div class="prev_view">
        <button onclick="change_view('previous')"  title="Click for previous slide"> <i class="pe-7s-angle-left"></i> </button>
        <span class="next_line"> Back </span>
    </div>

    <div class="next_view">
        <span class="next_line arrow_right"> Next </span>
        <button onclick="change_view('next')" title="Click for next slide"> <i class="pe-7s-angle-right"></i> </button>
    </div>

</section>