<section id="announcement">
    
    <div id="announcement_area">
        <span onclick="close_announcement()"> <i class="pe-7s-close"></i> </span>

        <p dd_display="content">
        </p>

        <div>
            <a dd_attr="id" href="[link]" target="_blank"> Click here <i class="icon pe-7s-angle-right"> </i> </a>
        </div>
    </div>

</section>