<section id="admin_dashboard" backTo="home">
    <p> What do you want to do next? </p>
    <a name="check_numbers">  <i class="pe-7s-call"></i> <span> Check phone numbers </span> <i class="pe-7s-angle-right"></i> </a>
    <a name="change_announcement">  <i class="pe-7s-speaker"></i> <span> Change announcement  </span> <i class="pe-7s-angle-right"></i>  </a>
</section>