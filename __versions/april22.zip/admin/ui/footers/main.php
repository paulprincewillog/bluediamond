
    </main>

<footer>
	<a href="<?php echo ROOT_URL; ?>"> Back to Homepage </a>
	<p> <span> &copy; </span> Blue Diamond Schools <?php echo date('Y'); ?> </p>
</footer>

</body>
</html>