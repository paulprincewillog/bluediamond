
    </main>

    <footer>
        <a> Contact us </a>
        <a> <img src="_assets/icons/facebook-grey.svg" alt="Facebook logo"> Facebook </a>
        <a> <img src="_assets/icons/whatsapp-grey.svg" alt="WhatsApp logo"> WhatsApp </a>
        <p> <span> &copy; </span> Blue Diamond Schools <?php echo date('Y'); ?> </p>
    </footer>

</body>
</html>