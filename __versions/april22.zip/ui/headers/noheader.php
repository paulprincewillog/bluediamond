<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title><?php echo $page_title; ?> | Blue Diamond Schools Effurun, Warri - bluediamondschools.com </title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel="stylesheet" href="ui/_general/_styles.dd.css">
    <link rel="stylesheet" href="ui/<?php echo $page_link; ?>/_styles.dd.css">
    <link rel="stylesheet" href="_assets/icons/pe-icon/styles/pe-icon.css">
</head>
<body>
    

	<dd_loader>
		<div dd_ajaxload></div>
	</dd_loader>