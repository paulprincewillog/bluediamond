<header id="header">
    
    <?php loadUI('announcement'); ?>

    <section id="main_header">

        <div id="logo">
            <img src="_assets/logo/blue diamond warri logo.png">
        </div>

        <div id="main_links">

            <a class="dd_shortline"> <i class="pe-7s-call"></i> Call 070 6198 8188</a>

            <!-- <a> <img src="_assets/icons/facebook-1.svg" class="icon"> </a>
            <a href="https://wa.me/2349035069626?text=I am messaging from faithmodel.school and I want to ... "> <img src="_assets/icons/whatsapp-1.svg" class="icon"> </a> -->

            <a> Visit our school </a>
            <!-- <a href="tel: +2347061988188"> <i class="pe-7s-call"></i> Call: +23470 6198 8188 </a> -->
        </div>
        
    </section>

</header>

<main>