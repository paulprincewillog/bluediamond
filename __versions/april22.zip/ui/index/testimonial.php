    <div id="testimonial_container">
        
        <h2> Parents around Effurun <br> trust our standards </h2>
        <div class="blinking_circle"></div>
        <div id="testimonial">

            <div class="each_testimonial">

                    <img src="_assets/images/parent-from-our-school-in-effurun.jpg" class="testimonial_image" alt="One of our parent at Blue Diamond Schools ">
                    <p class="caption">
                        I moved into Effurun and was looking for a good school for my 3 year old child. I was impressed with the way my neighbours child behaved and found out they were students of Blue Diamond schools. I have not regretted the choice I made as I have gotten a good experince so far.    
                    </p>  
                    <div class="author">
                        <span class="line"></span>
                        <p> Mrs Chukwunonso I. <span> From UTI Road </span> </p>
                    </div>

            </div>

            <div class="each_testimonial">

                <img src="_assets/images/another-parent-from-effurun.jpg" class="testimonial_image" alt="another parent of blue diamond schools who gave a good rating">
                <p class="caption">
                    I have been with Blue Diamond for three years now and have not changed my mind. They give my child teaching standards that is higher than his level so he can grow, and I have seen the improvements over time. My other son have also started schooling there too.   
                </p> 
                <div class="author">
                    <span class="line"></span>
                    <p> Mrs Okitiakpe T. <span> From Alegbo </span> </p>
                </div>

            </div>

        </div>

    </div>

    <!-- <section id="schedule_button"> 
        <button onclick="cta('cta_schedule')"> Schedule a visit now <i class="pe-7s-stopwatch"></i> </button> 
        <a href="https://wa.me/2347085898670?text=I am messaging from Blue Diamond school and I want to ... " class="whatsapp_button"> <button> Message on WhatsApp <img src="_assets/icons/whatsapp.svg" width="14" alt="WhatsApp logo"> </button> </a>
    </section> -->
<!-- 
    <section class="navigation">
        
        <div class="next_view">
            <span class="next_line arrow_right"> View more details </span>
            <button onclick="change_view('next')" title="Click to view more"> <i class="pe-7s-angle-right"></i> </button>
        </div>

    </section> -->

</section>